# Deployment

- Laravel can be deployed using [Laravel Cloud](https://cloud.laravel.com/), which is the fastest way to deploy and scale production Laravel applications.
<?php /**PATH /Users/zubdev/Workspace/clients/pay2me/paykonnet_backend/storage/framework/views/2d21c7721a51fb6d42304f35ce55c99a.blade.php ENDPATH**/ ?>